<html>
    <head>
        <style>
            button{
                font-weight: bold;
                color: black;
                background-color: #2196F3;
                border-radius: 10px;
                padding: 15;
                background-repeat: no-repeat;
                background-size: auto;
                border: 1px solid black;
                display: block;
                outline:none;
            }
            button:hover{
                background-color: #ccc;
            }
        </style>
    </head>
    <body>
        <center>
            <h2>Successfully created account</h2>
            <img src="succe.gif">
            <br>
            <p>For log in click below</p>
            <a href="index.php"><button>Login</button></a>
        </center>
    </body>
</html>